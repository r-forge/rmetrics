# Example script for MS_Regress_Fit

# Remember to install the package Rdnlop2 available at:
#
# http://arumat.net/Rdonlp2/
#
# After that, just run the script
# Author: Marcelo Perlin (marceloperlin@gmail.com)

library("Rdonlp2")
myPath<-"D:/fMarkovSwitching_PROCEDURAL"    # change your path here

setwd(myPath)

source("MS_Regress_Fit.r")
source("MS_Regress_Simul.r")
source("MS_Class_Fit.r")
source("MS_Class_Simul.r")
source("MS_Regress_For.R")
source("MS_Regress_Lik.r")

dep<-read.table("dep.txt")
indep<-read.table("indep.txt")

dep<-as.matrix(dep)
indep<-as.matrix(indep)

S=c(1,0,0)
distrib<-"t"
k<-2

myModel<-MS_Regress_Fit(dep,indep,S,k,distrib)
print(myModel)
plot(myModel)
